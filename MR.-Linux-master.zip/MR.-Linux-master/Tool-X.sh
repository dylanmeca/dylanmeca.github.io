#!/bin/bash
apt update
pkg update && pkg upgrade
pkg install git -y
git clone https://github.com/rajkumardusad/Tool-X
cd Tool-X
chmod 777 install.aex

