#!/data/data/com.termux/files/usr/bin/bash -e
pkg update && pkg upgrade
pkg install git
cd --
git clone https://github.com/noobfoda2/tool
clear
ls
cd tool;ls
chmod +× kali;ls
bash kali
