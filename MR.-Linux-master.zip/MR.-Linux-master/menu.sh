#!/bin/bash
setterm -foreground green               
clear
apt-get install -y tar proot wget 
menu()
{
clear
echo -e "\n\e[93m@root\n"
echo -e "\n\e[5;91m   1- Instalar tool"
echo -e "\e[5;96m   2- Instalar Metasploit"
echo -e "\e[5;92m   3- Instalar Kali-NetHunter"
echo -e "\e[5;92m   4- Salir"
echo -e -n "\e[5;92m \n >>>  "
read res
case $res in
"1")
clear
pkg install git -y
cd --
git clone https://github.com/noobfoda2/tool
cd MR.-Linux-master
clear
echo -e "\n\e[5;96m Regresar al menu s/n?"
read s
if [ "$s" = "s" ]; then 
menu
else
echo "saliendo.."
exit
fi
;;
"2")
clear
pkg install wget
wget https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh
ls
chmod 777 metasploit.sh
sh metasploit.sh
echo -e "\e[5;96m Regresar al menu s/n?"
read s
if [ "$s" = "s" ]; then 
menu
else
echo "saliendo.."
exit
fi
;;
"3")
clear
cd --
pkg install wget openssl-tool proot -y && hash -r && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Nethunter/nethunter.sh && bash nethunter.sh
cd  MR.-Linux-master
echo -e "\e[5;96m Regresar al menu s/n?"
read s
if [ "$s" = "s" ]; then 
menu
else
echo "saliendo.."
exit
fi
;;
"4")
exit
;;
esac
}
menu

