#!/data/data/com.termux/files/usr/bin/bash 
pkg update && pkg upgrade
pkg install python2
pkg install git
cd --
git clone https://github.com/Gameye98/Lazymux
cd Lazymux;ls
chmod 777 lazymux.py
python2 lazymux.py
