#!/bin/bash
pkg update && pkg upgrade
pkg install figlet -y
pkg install git -y
pkg install wget -y
clear
#menu
setterm -foreground red
echo " Disclaimer "
echo " la instalación de metasploit, corre a tu bajo riesgo"
echo " No me hago Responsable por el mal uso"
echo " Escribe y si confirmas la instalación de Metasploit"
read $confirmacion
echo " ### $confirmacion "
clear
#instalacion
setterm -foreground green
cd --
wget https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh
chmod +x metasploit.sh && ./metasploit.sh
clear
#salida
setterm -foreground green
echo " Instalación completa "
echo " puede usar directamente msfvenom o msfconsole en lugar de ./msfvenom o ./msfconsole "
echo " Pulsa ENTER para salir de aquí "
read ENTER
echo " Saliendo ... "
clear
echo " puede usar directamente msfvenom o msfconsole en lugar de ./msfvenom o ./msfconsole "




