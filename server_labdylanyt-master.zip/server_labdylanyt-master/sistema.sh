#!/bin/bash
pkg install wget
cd --
wget https://dylan14567.github.io/Laboratorio-SUPERDYLANYT/MR.-Linux-master.zip
pkg install unzip
unzip MR.-Linux-master.zip
ls
rm MR.-Linux-master.zip
ls

#login
echo " Inicia Sección "
echo " no nesecitas una contraseña para iniciar seción solo el nombre "
echo " Escribe tu nombre de usuario ?? "
read nombre
echo " hola $nombre estamos trabajando en el sistema ya casi esta listo "

#menu
             setterm -foreground cyan
echo                      "####################"
echo                      "     BIENVENIDO     "
echo                      "       MR. Linux    "
echo                      "code by SUPERDYLANYT"                    
echo                      "####################"
                setterm -foreground green
                
echo " $nombre bienvenido a MR. Linux "
cd server_labdylanyt
rm sistema.sh



