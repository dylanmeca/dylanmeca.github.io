#!/bin/bash

pkg update && pkg upgrade
pkg install util-linux -y
pkg install figlet -y
clear
sh menu.sh
rm install.sh


